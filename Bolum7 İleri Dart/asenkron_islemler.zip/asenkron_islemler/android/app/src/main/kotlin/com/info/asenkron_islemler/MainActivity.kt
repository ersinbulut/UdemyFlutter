package com.info.asenkron_islemler

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
