package com.info.ileri_dart

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
