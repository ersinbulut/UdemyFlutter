package com.info.standartprogramlama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
