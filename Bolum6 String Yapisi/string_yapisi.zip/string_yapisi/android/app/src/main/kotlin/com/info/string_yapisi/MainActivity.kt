package com.info.string_yapisi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
