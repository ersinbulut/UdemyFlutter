import 'package:nesne_tabanli_programlama2/Arac.dart';

class Araba extends Arac  {
    String kasaTipi;

    Araba(this.kasaTipi,String renk, String vites) : super(renk, vites);
}

