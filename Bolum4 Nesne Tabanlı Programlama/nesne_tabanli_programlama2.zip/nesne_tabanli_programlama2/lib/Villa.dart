
import 'package:nesne_tabanli_programlama2/Ev.dart';

class Villa extends Ev {
  bool garajVarmi;

  Villa(this.garajVarmi,int pencereSayisi) : super(pencereSayisi);
}

