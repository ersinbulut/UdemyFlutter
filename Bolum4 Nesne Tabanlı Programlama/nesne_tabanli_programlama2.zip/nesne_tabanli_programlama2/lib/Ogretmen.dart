import 'package:nesne_tabanli_programlama2/Personel.dart';

class Ogretmen extends Personel{
  void maasArttir(){
    print("Maaş arttı.Öğretmen Mutlu :)");
  }
}

