import 'package:nesne_tabanli_programlama2/ClassA.dart';

void main(){

  var a = ClassA();

  print(a.degisken);
  a.metod1();
  print(a.metod2());

}