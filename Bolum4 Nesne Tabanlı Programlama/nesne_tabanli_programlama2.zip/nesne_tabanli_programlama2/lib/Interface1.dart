abstract class Interface1{
  int degisken;

  void metod1();

  String metod2();
}

