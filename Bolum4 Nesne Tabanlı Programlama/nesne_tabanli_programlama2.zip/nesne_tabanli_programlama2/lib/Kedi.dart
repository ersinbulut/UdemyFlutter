import 'package:nesne_tabanli_programlama2/Memeli.dart';

class Kedi extends Memeli {
  @override
  void sesCikar() {
    print("Miyav Miyav");
  }
}

