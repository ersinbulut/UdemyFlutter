
  import 'package:nesne_tabanli_programlama2/Ev.dart';

 class Saray extends Ev {
    int kuleSayisi;

    Saray(this.kuleSayisi,int pencereSayisi) : super(pencereSayisi);
 }


