class Kategoriler {
  int kategori_id;
  String kategori_ad;

  Kategoriler(this.kategori_id, this.kategori_ad);
}

