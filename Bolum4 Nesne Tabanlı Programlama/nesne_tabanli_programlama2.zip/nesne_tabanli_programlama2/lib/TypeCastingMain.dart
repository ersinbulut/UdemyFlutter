import 'package:nesne_tabanli_programlama2/Ev.dart';
import 'package:nesne_tabanli_programlama2/Saray.dart';

void main(){

  /*var ev = Ev(5);

  var saray = ev as Saray;
  //Downcasting*/

  var saray = Saray(10,200);

  var ev = saray ;
  //Upcasting

}
