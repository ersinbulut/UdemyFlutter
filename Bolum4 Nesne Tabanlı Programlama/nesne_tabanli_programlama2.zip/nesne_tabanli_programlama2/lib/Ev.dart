
  class Ev {
    int pencereSayisi;

    Ev(this.pencereSayisi);
  }


  