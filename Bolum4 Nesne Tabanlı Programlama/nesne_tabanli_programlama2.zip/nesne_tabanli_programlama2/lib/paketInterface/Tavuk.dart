import 'package:nesne_tabanli_programlama2/paketInterface/Eatable.dart';

class Tavuk implements Eatable {
  @override
  void howToEat() {
    print("Fırında kızart");
  }
}

