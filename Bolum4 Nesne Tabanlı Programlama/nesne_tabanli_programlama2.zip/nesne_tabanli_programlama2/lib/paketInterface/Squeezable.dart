abstract class Squeezable {
  void howToSqueeze();
}


