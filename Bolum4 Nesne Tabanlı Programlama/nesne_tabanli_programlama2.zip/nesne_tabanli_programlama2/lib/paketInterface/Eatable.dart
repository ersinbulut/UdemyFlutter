abstract class Eatable {
  void howToEat();
}

