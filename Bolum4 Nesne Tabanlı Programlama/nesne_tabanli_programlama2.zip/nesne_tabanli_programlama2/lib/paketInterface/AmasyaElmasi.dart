import 'package:nesne_tabanli_programlama2/paketInterface/Elma.dart';

class AmasyaElmasi extends Elma {
  @override
  void howToEat() {
    print("Yıka ve ye");
  }
}

