
  class Arac {
      String renk;
      String vites;

      Arac(this.renk, this.vites);
  }

