import 'package:nesne_tabanli_programlama2/Hayvan.dart';

class Memeli extends Hayvan {

}


