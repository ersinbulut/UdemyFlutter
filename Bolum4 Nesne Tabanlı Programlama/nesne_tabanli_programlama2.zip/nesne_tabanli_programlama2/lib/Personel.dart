class Personel {
  void iseAlindi(){
    print("Personel mutlu");
  }
}


