import 'package:nesne_tabanli_programlama2/Araba.dart';

void main(){

  var araba = Araba("Sedan","Kırmızı","Otomatik");

  print(araba.kasaTipi);
  print(araba.renk);
  print(araba.vites);

}