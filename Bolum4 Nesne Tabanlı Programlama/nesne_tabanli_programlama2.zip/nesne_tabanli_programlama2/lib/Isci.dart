import 'package:nesne_tabanli_programlama2/Personel.dart';

class Isci extends Personel{

}


