import 'package:nesne_tabanli_programlama2/Memeli.dart';

class Kopek extends Memeli {
    @override
    void sesCikar() {
      print("Hav Hav");
    }
}

