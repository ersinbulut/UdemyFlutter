import 'package:nesne_tabanli_programlama2/Adres.dart';

class Kisiler{
    String ad;
    int yas;
    Adres adres;

    Kisiler(this.ad, this.yas, this.adres);
}

