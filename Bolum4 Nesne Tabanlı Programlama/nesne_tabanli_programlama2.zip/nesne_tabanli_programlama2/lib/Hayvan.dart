class Hayvan {
    void sesCikar(){
      print("Ses yok");
    }
}

