package com.info.nesne_tabanli_programlama

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
