import 'package:nesne_tabanli_programlama/Asinifi.dart';

void main(){

  print(Asinifi.degisken);

  Asinifi.degisken = 100;
  print(Asinifi.degisken);

  print(Asinifi.oran);

  Asinifi.metod();


}