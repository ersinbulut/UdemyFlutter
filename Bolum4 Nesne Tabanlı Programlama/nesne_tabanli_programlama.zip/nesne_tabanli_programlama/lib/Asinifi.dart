class Asinifi{

  static int degisken = 10;

  static final double oran = 10.45;

  static void metod(){
    print("Merhaba");
  }

}

