import 'package:nesne_tabanli_programlama/Odev3.dart';

void main(){

  var o3 = Odev3();

  int gelenVeri = o3.faktoriyelHesaplama(5);
  print("Faktoriyel : $gelenVeri");

}


