
  enum Renkler{
    Beyaz,Siyah
  }

