import 'package:nesne_tabanli_programlama/Odev7.dart';

void main(){

  var o7 = Odev7();

  int sonuc = o7.internetUcretiHesaplama(40);
  print("Ücret : $sonuc");


}