import 'package:nesne_tabanli_programlama/Odev6.dart';

void main(){

  var o6 = Odev6();

  int sonuc = o6.maasHesaplama(30);
  print("Maaş : $sonuc");

}