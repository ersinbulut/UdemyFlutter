import 'package:nesne_tabanli_programlama/Odev4.dart';

void main(){

  var o4 = Odev4();

  o4.kelimeAdeti("ankara","a");

}

