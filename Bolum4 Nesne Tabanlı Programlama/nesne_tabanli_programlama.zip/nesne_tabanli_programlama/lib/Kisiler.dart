
  class Kisiler{
    String ad;
    int yas;

    Kisiler(this.ad, this.yas);
 }

