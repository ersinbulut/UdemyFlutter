class Odev1 {

  double donustur(double derece){

    double fahrenhiet = derece*1.8 + 32;
    return fahrenhiet;

  }

}



