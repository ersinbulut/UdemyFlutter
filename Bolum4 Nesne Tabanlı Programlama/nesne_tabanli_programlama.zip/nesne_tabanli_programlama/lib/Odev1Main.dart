import 'package:nesne_tabanli_programlama/Odev1.dart';

void main(){

  var o1 = Odev1();

  double sonuc = o1.donustur(30.0);
  print("Fahrenhiet : $sonuc");


}


