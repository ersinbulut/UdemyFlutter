import 'package:nesne_tabanli_programlama/Odev2.dart';

void main(){

  var o2 = Odev2();

  o2.cevre(30,40);


}


