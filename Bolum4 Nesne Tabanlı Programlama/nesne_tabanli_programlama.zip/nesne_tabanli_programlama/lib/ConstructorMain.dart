import 'package:nesne_tabanli_programlama/Kisiler.dart';

void main(){

  var kisi = Kisiler("Ahmet",23);

  print(kisi.ad);
  print(kisi.yas);

}