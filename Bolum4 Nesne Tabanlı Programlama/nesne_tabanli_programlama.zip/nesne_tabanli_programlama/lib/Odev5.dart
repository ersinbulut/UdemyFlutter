class Odev5 {

  int icAciToplama(int kenarSayi){

    int toplam = (kenarSayi-2)*180;
    return toplam;

  }

}


