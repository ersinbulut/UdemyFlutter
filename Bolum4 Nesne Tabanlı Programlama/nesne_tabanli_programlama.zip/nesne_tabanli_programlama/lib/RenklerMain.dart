import 'package:nesne_tabanli_programlama/Renkler.dart';

void main(){

  var renk = Renkler.Beyaz;

  switch(renk){
    case Renkler.Beyaz:{
      print("#FFFFFFF");
    }
    break;

    case Renkler.Siyah:{
      print("#000000");
    }
    break;
  }


}