class Odev2 {

  void cevre(int kisaKenar,int uzunKenar){

    int cevreHesabi = 2*kisaKenar + 2*uzunKenar;
    print("Dikdörtgen Çevresi : $cevreHesabi");

  }

}


