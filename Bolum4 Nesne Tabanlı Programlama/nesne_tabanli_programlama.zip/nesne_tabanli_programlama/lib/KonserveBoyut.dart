
  enum KonserveBoyut{
    Kucuk,Orta,Buyuk
  }

  