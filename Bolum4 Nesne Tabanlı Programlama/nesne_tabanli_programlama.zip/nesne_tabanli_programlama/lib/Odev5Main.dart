import 'package:nesne_tabanli_programlama/Odev5.dart';

void main(){

  var o5 = Odev5();

  int sonuc = o5.icAciToplama(3);
  print("İç açı toplamı : $sonuc");

}

