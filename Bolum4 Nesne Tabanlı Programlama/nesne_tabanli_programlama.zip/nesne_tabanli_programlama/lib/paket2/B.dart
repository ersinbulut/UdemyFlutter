import 'package:nesne_tabanli_programlama/paket1/A.dart';

class B{

  var a = A();

}

