
  class A{
      int publicDegisken;
      int _privateDegisken;

      int get privateDegisken {
        return _privateDegisken;
      }

      set privateDegisken(int privateDegisken) {
        this._privateDegisken = privateDegisken;
      }
  }

