import 'package:nesne_tabanli_programlama/paket1/A.dart';

void main(){

  var a = A();

  a.publicDegisken = 1 ;
  a.privateDegisken = 2;

  print(a.publicDegisken);
  print(a.privateDegisken);


}