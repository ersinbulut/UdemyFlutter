package com.example.null_safety_kullanimi

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
