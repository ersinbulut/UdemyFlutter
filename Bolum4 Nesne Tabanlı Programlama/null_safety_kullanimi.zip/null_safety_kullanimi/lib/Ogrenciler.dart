class Ogrenciler {
  int no;
  String ad;

  Ogrenciler({required this.no,required this.ad});
}