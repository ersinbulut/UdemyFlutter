class Kisiler {
    int kisi_no;
    String kisi_ad;

   Kisiler(this.kisi_no, this.kisi_ad);
}