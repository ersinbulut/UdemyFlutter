class LateKullanimi {
  late int x;

  late int y;
}