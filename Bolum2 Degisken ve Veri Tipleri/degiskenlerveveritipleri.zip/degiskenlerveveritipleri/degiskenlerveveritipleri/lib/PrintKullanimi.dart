void main(){

  var ad = "Ahmet";
  int yas = 10;

  print("$ad Bursada $yas yıldır yaşamaktadır.");

  int a = 10;
  var b = 20;

  print("$a ve $b nin toplamı : ${a+b}");





}