void main(){

  int sayi = 30 ;

  sayi = 50 ;

  final sonuc = 100;

  //sonuc = 200 ;

  final pi = 3.14;
  final String mesaj = "merhaba";
  const y = 20 ;
  const double a = 20.9 ;



}