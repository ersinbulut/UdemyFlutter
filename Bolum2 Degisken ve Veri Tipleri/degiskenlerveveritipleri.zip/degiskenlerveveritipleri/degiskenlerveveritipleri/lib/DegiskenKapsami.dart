import 'package:degiskenlerveveritipleri/Deneme.dart';

void main(){
  var d = Deneme();
  d.topla();//60
  d.carpma();//200
}

