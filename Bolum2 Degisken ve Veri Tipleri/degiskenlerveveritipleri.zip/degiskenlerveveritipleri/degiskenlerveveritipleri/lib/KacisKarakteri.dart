void main(){

    String yazi = "Mehmet \"Nasılsın\" dedi"; //Mehmet "Nasılsın" dedi
    print(yazi);

    var yazi1 = "Merhaba bu \"android\"\n\teğitiminde \\kotlin\\ dilini öğrenicez";
    print(yazi1);

}