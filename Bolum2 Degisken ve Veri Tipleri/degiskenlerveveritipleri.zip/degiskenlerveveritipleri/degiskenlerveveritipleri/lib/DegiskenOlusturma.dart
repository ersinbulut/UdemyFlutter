void main(){

  var ogrenciAdi = "Ahmet" ;
  var ogrenciYasi = 23;
  var ogrenciBoyu = 1.78;
  var ogrenciBasHarfi = "A";

  print(ogrenciAdi);
  print(ogrenciYasi);
  print(ogrenciBoyu);
  print(ogrenciBasHarfi);

  int urun_id = 3416;
  String urun_ad = "Kol Saati";
  int urun_adet = 100;
  double urun_fiyat = 109.99;
  String urun_tedarikci = "rolex";

  print("Ürün id : $urun_id");
  print("Ürün ad : $urun_ad");
  print("Ürün adet : $urun_adet");
  print("Ürün fiyat : $urun_fiyat");
  print("Ürün tedarikçi : $urun_tedarikci");


}