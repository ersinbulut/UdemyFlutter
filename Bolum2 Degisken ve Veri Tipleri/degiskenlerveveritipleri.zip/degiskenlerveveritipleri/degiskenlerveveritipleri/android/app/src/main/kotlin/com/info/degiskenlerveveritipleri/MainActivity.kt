package com.info.degiskenlerveveritipleri

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
