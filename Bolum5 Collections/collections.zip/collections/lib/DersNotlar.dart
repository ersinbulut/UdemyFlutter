class DersNotlar{
  String ders;
  int not;

  DersNotlar(this.ders, this.not);
}

