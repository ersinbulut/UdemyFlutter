import 'package:collections/Adres.dart';

class Personel{
  int no;
  String isim;
  Adres adres;

  Personel(this.no, this.isim, this.adres);
}

