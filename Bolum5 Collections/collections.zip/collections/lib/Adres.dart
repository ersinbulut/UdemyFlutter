class Adres {
  String il;
  String ilce;

  Adres(this.il, this.ilce);
}

